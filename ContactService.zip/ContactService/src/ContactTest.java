//George Harrison Jr
//ContactTest.java
//CS-320

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {
	//Testing true conditions.
	@Test
	void testContact() {
		
		Contact contact = new Contact("Gregg","Hall","555 High Ln","35t67i","1234567890");
		assertTrue(contact.getFirstName().equals("Gregg"));
		assertTrue(contact.getLastName().equals("Hall"));
		assertTrue(contact.getAddress().equals("555 High Ln"));
		assertTrue(contact.getContactId().equals("35t67i"));
		assertTrue(contact.getNumber().equals("1234567890"));
	}
	
//	//Testing Exceptions
	@Test
	void testContactTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("Greggory    ","Hall","555 High Ln","35t67i","1234567890");});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("Gregg","Halliston    ","555 High Ln","35t67i","1234567890");});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("Gregg","Hall","555 High Lnnaasdf;lk;          ","35t67i","1234567890");});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("Greg","Hall","555 High Ln","35t67i0987612344","1234567890");});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("Greggory    ","Hall","555 High Ln","35t67i","123456789");});
	}
}
