//George Harrison Jr
//ContactService.java
//CS-320
 public class ContactService extends Contact{
	 
	 
	//declare variables.
	private String uniqueId;
	private String lastName;
	private String firstName;
	private String address;
	private String number;
	private String contactId;
	//constructor for Contact Service.
	public ContactService(String uniqueId,String firstName, String lastName, String address,  String contactId, String number) {
			 super(firstName,lastName,address,contactId,number);
			 this.uniqueId = uniqueId;
	}
	
	//add unique Id.
	public String getUniqueId() {return uniqueId;}
	
	//Delete Contact Id.
	public String deleteContactId() {
		contactId = getContactId();
		contactId = null;
		return contactId;
	}
	//Update new firstName.
	public String updateFirstName() {
		firstName = getFirstName();
		firstName = this.firstName;
		return firstName;
	}
	
	//Update new lastName.
		public String updateLastName() {
			lastName = getLastName();
			lastName = this.lastName;
			return lastName;
		}
		
	//Update new number.
		public String updateNumber() {
			number = getNumber();
			number = this.number;
			return number;
		}
	//Update new address.
		public String updateAddress() {
			address = getAddress();
			address = this.address;
			return address;
		}	
		
}
