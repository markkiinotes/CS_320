//George Harrison Jr
//Contact.java
//CS-320

public class Contact {
	//private String contactList[];
	private String firstName;
	private String lastName;
	private String address;
	private String contactId;
	private String number;
	
	//The requirement for student ID is that it cannot be null and it cannot be
	//longer than 5 characters or through an exception.
	public Contact(String firstName,String lastName, String address, String contactId, String number ){
		if(contactId == null || contactId.length() > 10) {
			//We want to test contact id exception
			throw new IllegalArgumentException("Invalid input - contactId");
		}
		
		if(firstName == null || firstName.length() > 10) {
			//We want to test first name exception
			throw new IllegalArgumentException("Invalid input - first name");
		}
		
		if(lastName == null ||lastName.length() > 10) {
			//We want to test last name exception
			throw new IllegalArgumentException("Invalid input - last name");
		}
		
		if(number == null || number.length() != 10) {
			//We want to test number exception
			throw new IllegalArgumentException("Invalid input - number");
		}
		
		if(address == null || address.length() > 30) {
			//We want to test address exception
			throw new IllegalArgumentException("Invalid input - address");
		}
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.contactId = contactId;
		this.number = number;
	}
	
	public String getFirstName() {return firstName;}
	
	public String getLastName() {return lastName;}
	
	public String getAddress() {return address;}
	
	public String getContactId() {return contactId;}
	
	public String getNumber() {return number;}
}
