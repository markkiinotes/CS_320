//George Harrison Jr
//ContactServiceTest.java
//CS-320

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
@Test
	void TestContactService() {
		ContactService service = new ContactService("12345678","Gregg","Hall","555 High Ln","35t67i","1234567890");
	
		assertTrue(service.getUniqueId().equals("12345678"));
	}

@Test
	void TestContactServiceTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {new ContactService("12345678901","Gregg","Hall","555 High Ln","35t67i","1234567890");});
}
}
